var x = parseInt(prompt("Ile posiadasz gotówki: "));

if(x < 50)
  alert("Idziesz z kolegami na miasto");
else
  alert("Idzesz na k**wy");